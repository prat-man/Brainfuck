#include <stdio.h>
#include <stdlib.h>
#include "stack.h"

Stack* stackCreate(int size) {
    Stack* stack = (Stack*) malloc(sizeof(Stack));
    stack->array = (int*) malloc(sizeof(int) * size);
    stack->size = size;
    stack->tos = -1;
    return stack;
}

void stackPush(Stack* stack, int value) {
    if (stack->tos == stack->size - 1) {
        printf("Stack Overflow!\n");
        exit(1);
    }
    stack->array[++stack->tos] = value;
}

int stackPop(Stack* stack) {
    if (stack->tos == -1) {
        printf("Stack Underflow!\n");
        exit(1);
    }
    return stack->array[stack->tos--];
}

int stackPeek(Stack* stack) {
    if (stack->tos == -1) {
        printf("Stack Underflow!\n");
        exit(1);
    }
    return stack->array[stack->tos];
}

int stackEmpty(Stack* stack) {
    if (stack->tos == -1) return 1;
    return 0;
}

void stackFree(Stack* stack) {
    free(stack->array);
    free(stack);
}
