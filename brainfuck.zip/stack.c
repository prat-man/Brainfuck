#include <stdio.h>
#include <stdlib.h>
#include "stack.h"

void stackInit(Stack* stack, int size) {
    stack->array = (int*) malloc(sizeof(int) * size);
    stack->size = size;
    stack->tos = -1;
}

void stackPush(Stack* stack, int value) {
    if (stack->tos == stack->size - 1) {
        printf("Stack Overflow!\n");
        exit(1);
    }
    stack->array[++stack->tos] = value;
}

int stackPop(Stack* stack) {
    if (stack->tos == -1) {
        printf("Stack Underflow!\n");
        exit(1);
    }
    return stack->array[stack->tos--];
}

int stackPeek(Stack* stack) {
    if (stack->tos == -1) {
        printf("Stack Underflow!\n");
        exit(1);
    }
    return stack->array[stack->tos];
}

int stackEmpty(Stack* stack) {
    if (stack->tos == -1) return 1;
    return 0;
}
