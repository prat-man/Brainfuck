#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include "stack.h"

#define TAPE_SIZE 30000
#define STACK_SIZE 1000

char* source = NULL;
int* jumps = NULL;
int filePointer = 0;
int fileSize;

unsigned char* tape;
int pointer = 0;

void loadFile(char* filePath) {
    FILE* fp = fopen(filePath, "r");

    if (fp != NULL) {
        /* Go to the end of the file. */
        if (fseek(fp, 0L, SEEK_END) == 0) {
            /* Get the size of the file. */
            long bufsize = ftell(fp);
            if (bufsize == -1) { /* Error */ }

            /* Allocate our buffer to that size. */
            source = (char*) malloc(sizeof(char) * (bufsize + 1));

            /* Go back to the start of the file. */
            if (fseek(fp, 0L, SEEK_SET) != 0) { /* Error */ }

            /* Read the entire file into memory. */
            size_t newLen = fileSize = fread(source, sizeof(char), bufsize, fp);
            if (ferror( fp ) != 0) {
                fputs("Error reading file", stderr);
            } else {
                source[newLen++] = '\0'; /* Just to be safe. */
            }
        }

        /* Close the file */
        fclose(fp);
    }
    else {
        printf("File not found!\n");
        exit(1);
    }
}

/**
 * Initialize the jumps in the file for optimization.
 * Jumps between [ and ].
 * Compacts and jumps consecutive > and <.
 * Compacts and jumps consecutive + and -.
 */
void initJumps() {
    // initialize jumps
    jumps = (int*) malloc(sizeof(int) * (fileSize));

    // create a stack for [ operators
    Stack* stack = stackCreate(STACK_SIZE);

    // find jumps to optimize code
    for (int i = 0; i < fileSize; i++) {
        // get one character
        char ch = source[i];

        // create jumps for opening and closing square brackets [ and ]
        if (ch == '[') {
            stackPush(stack, i);
        }
        else if (ch == ']') {
            int x = stackPop(stack);
            jumps[x] = i;
            jumps[i] = x;
        }

        // compact and jump for > and <
        else if (ch == '>' || ch == '<') {
            int sum = 0;

            if (ch == '>') sum++;
            else sum--;

            int index = i;
            while (++i < fileSize) {
                if (source[i] == '>') {
                    sum++;
                }
                else if (source[i] == '<') {
                    sum--;
                }
                else {
                    break;
                }
            }
            i--;
            if (index == i) {
                jumps[index] = INT_MAX;
            }
            else {
                jumps[index] = i;
                jumps[i] = sum;
            }
        }

        // compact and jump for + and -
        else if (ch == '+' || ch == '-') {
            int sum = 0;

            if (ch == '+') sum++;
            else sum--;

            int index = i;
            while (++i < fileSize) {
                if (source[i] == '+') {
                    sum++;
                }
                else if (source[i] == '-') {
                    sum--;
                }
                else {
                    break;
                }
            }
            i--;
            if (index == i) {
                jumps[index] = INT_MAX;
            }
            else {
                jumps[index] = i;
                jumps[i] = sum;
            }
        }

        // everything else, no jumps
        else {
            jumps[i] = 0;
        }
    }

    // loops are unmatched
    if (!stackEmpty(stack)) {
        // free stack
        stackFree(stack);

        // show error message and exit
        printf("Unmatched loops!");
        exit(1);
    }

    // free stack
    stackFree(stack);
}

/**
 * Read a single character from the source file.
 */
char readChar() {
    if (filePointer == fileSize) {
        return -1;
    }
    return source[filePointer++];
}

/**
 * Perform the operation represented by the character.
 * Ignore character if it is not an operator.
 */
void doOperation(char ch) {
    if (ch == '>' || ch == '<') {
        int index = jumps[filePointer - 1];

        if (index == INT_MAX) {
            if (ch == '>') {
                pointer = (pointer + 1) % TAPE_SIZE;
            }
            else {
                if (pointer == 0) {
                    pointer = TAPE_SIZE - 1;
                }
                else {
                    pointer--;
                }
            }
        }
        else {
            int sum = jumps[index];

            if (sum > 0) {
                pointer = (pointer + sum) % TAPE_SIZE;
            }
            else if (sum < 0) {
                pointer = (pointer + sum);
                if (pointer < 0) {
                    pointer = TAPE_SIZE + pointer;
                }
            }

            filePointer = index + 1;
        }
    }
    else if (ch == '+' || ch == '-') {
        int index = jumps[filePointer - 1];

        if (index == INT_MAX) {
            if (ch == '+') {
                tape[pointer]++;
            }
            else {
                tape[pointer]--;
            }
        }
        else {
            int sum = jumps[index];
            tape[pointer] += sum;
            filePointer = index + 1;
        }
    }
    else if (ch == '.') {
        printf("%c", tape[pointer]);
        fflush(stdout);
    }
    else if (ch == ',') {
        tape[pointer] = getchar();
        fflush(stdin);
    }
    else if (ch == '[') {
        if (tape[pointer] == 0) {
            filePointer = jumps[filePointer - 1] + 1;
        }
    }
    else if (ch == ']') {
        if (tape[pointer] != 0) {
            filePointer = jumps[filePointer - 1] + 1;
        }
    }
}

void clean() {
    free(source);
    free(jumps);
    free(tape);
}

void execute(char* filePath) {
    // clean before exit
    atexit(clean);

    // initialize tape and fill with zeros
    tape = (unsigned char*) malloc(sizeof(unsigned char) * (TAPE_SIZE));
    memset(tape, 0, TAPE_SIZE);

    // load source file
    loadFile(filePath);

    // initialize file jumps for optimization
    initJumps();

    // for each character do operation
    char ch;
    while ((ch = readChar()) != -1) {
        doOperation(ch);
    }
}

int main(int argc, char** argv) {
    /*if (argc < 2) {
        printf("Usage: brainfuck [source file path]\n");
    }
    else {
        execute(argv[1]);
    }*/
    execute("mandelbrot.bf");
    return 0;
}
