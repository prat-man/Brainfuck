#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "stack.h"

#define TAPE_SIZE 30000
#define STACK_SIZE 1000
#define LOOP_SIZE 1000

char* source = NULL;
int* loops = NULL;
int filePointer = 0;
int fileSize;

unsigned char* tape;
int pointer = 0;

void loadFile(char* filePath) {
    FILE* fp = fopen(filePath, "r");

    if (fp != NULL) {
        /* Go to the end of the file. */
        if (fseek(fp, 0L, SEEK_END) == 0) {
            /* Get the size of the file. */
            long bufsize = ftell(fp);
            if (bufsize == -1) { /* Error */ }

            /* Allocate our buffer to that size. */
            source = (char*) malloc(sizeof(char) * (bufsize + 1));

            /* Go back to the start of the file. */
            if (fseek(fp, 0L, SEEK_SET) != 0) { /* Error */ }

            /* Read the entire file into memory. */
            size_t newLen = fileSize = fread(source, sizeof(char), bufsize, fp);
            if (ferror( fp ) != 0) {
                fputs("Error reading file", stderr);
            } else {
                source[newLen++] = '\0'; /* Just to be safe. */
            }
        }

        /* Close the file */
        fclose(fp);
    }
    else {
        printf("File not found!\n");
        exit(1);
    }
}

void initLoops() {
    loops = (int*) malloc(sizeof(int) * (fileSize));

    Stack stack;

    stackInit(&stack, STACK_SIZE);

    for (int i = 0; i < fileSize; i++) {
        char ch = source[i];
        if (ch == '[') {
            stackPush(&stack, i);
        }
        else if (ch == ']') {
            int x = stackPop(&stack);
            loops[x] = i;
            loops[i] = x;
        }
    }

    if (!stackEmpty(&stack)) {
        printf("Unmatched loops!");
        exit(1);
    }
}

char readChar() {
    if (filePointer == fileSize) {
        return -1;
    }
    return source[filePointer++];
}

void doOperation(char ch) {
    if (ch == '>') {
        pointer++;
        if (pointer == TAPE_SIZE) {
            pointer = 0;
        }
    }
    else if (ch == '<') {
        if (pointer == 0) {
            pointer = TAPE_SIZE - 1;
        }
        else {
            pointer--;
        }
    }
    else if (ch == '+') {
        tape[pointer]++;
    }
    else if (ch == '-') {
        tape[pointer]--;
    }
    else if (ch == '.') {
        printf("%c", tape[pointer]);
        fflush(stdout);
    }
    else if (ch == ',') {
        tape[pointer] = getchar();
        fflush(stdin);
    }
    else if (ch == '[') {
        if (tape[pointer] == 0) {
            filePointer = loops[filePointer - 1] + 1;
        }
    }
    else if (ch == ']') {
        if (tape[pointer] != 0) {
            filePointer = loops[filePointer - 1] + 1;
        }
    }
}

void clean() {
    free(source);
    free(loops);
    free(tape);
}

void execute(char* filePath) {
    tape = (unsigned char*) malloc(sizeof(unsigned char) * (TAPE_SIZE));
    memset(tape, 0, TAPE_SIZE);

    loadFile(filePath);
    initLoops();

    char ch;
    while ((ch = readChar()) != -1) {
        doOperation(ch);
    }

    clean();
}

int main(int argc, char** argv) {
    /*if (argc < 2) {
        printf("Usage: brainfuck [source file path]\n");
    }
    else {
        execute(argv[1]);
    }*/
    execute("random.bf");
    return 0;
}
