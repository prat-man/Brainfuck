#ifndef STACK_H_INCLUDED
#define STACK_H_INCLUDED

typedef struct Stack {
    int* array;
    int size;
    int tos;
} Stack;

void stackInit(Stack*, int);

void stackPush(Stack*, int);

int stackPop(Stack*);

int stackPeek(Stack*);

int stackEmpty(Stack*);

#endif // STACK_H_INCLUDED
