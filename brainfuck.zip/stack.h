#ifndef STACK_H_INCLUDED
#define STACK_H_INCLUDED

typedef struct Stack {
    int* array;
    int size;
    int tos;
} Stack;

Stack* stackCreate(int size);

void stackPush(Stack*, int);

int stackPop(Stack*);

int stackPeek(Stack*);

int stackEmpty(Stack*);

void stackFree(Stack*);

#endif // STACK_H_INCLUDED
